﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Sportsbet.Model
{
    public class Ticket
    {
        public int Id { get; set; }
        public double AllOdds 
        {
            get
            {
                double odds = 1;
                foreach (Event e in Events)
                    odds *= Choices[e];

                return odds;
            }
        }
        public int Stake { get; set; }
        public int ExpectedWin { get; set; }

        [NotMapped]
        public Dictionary<Event, double> Choices { get; set; } = new Dictionary<Event, double>();
        public List<Event> Events { get; set; }
            = new List<Event>();
    }
}
