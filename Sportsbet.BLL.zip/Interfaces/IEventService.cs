﻿using Sportsbet.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Sportsbet.BLL.Services
{
    public interface IEventService
    {
        Task<Event> GetEventAsync(int eventId);
        Task<IEnumerable<Event>> GetEventsAsync();
        Task<Event> InsertEventAsync(Event newProduct);
        Task UpdateEventAsync(int eventId, Event updatedEvent);
        Task DeleteEventAsync(int eventId);
        void SaveToJson(string path = "valami");
        void LoadFromJson(string path = "valami");

    }
}
