﻿using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Sportsbet.DB;
using Sportsbet.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;


namespace Sportsbet.BLL.Services
{
    public class EventService : IEventService
    {
        private readonly NorthwindContext _context;

        public EventService(NorthwindContext context)
        {
            _context = context;
            SeedDatabase(_context);
        }

        static void SeedDatabase(NorthwindContext ctx)
        {
            if (!ctx.Events.Any())
            {
                var category_1 = new Category
                {
                    Name = "Football"
                };

                var category_2= new Category
                {
                    Name = "Handball"
                };

                ctx.Add(category_1);
                ctx.Add(category_2);

                var event_1 = new Event
                {
                    HomeTeam = "Köln",
                    AwayTeam = "Mainz",
                    HomeOdds = 2.3,
                    DrawOdds = 3.0,
                    AwayOdds= 2.8,
                    Time = new DateTime(2020, 05, 17, 15, 30, 0),
                    Category = category_1
                };

                var event_2 = new Event
                {
                    HomeTeam = "Union Berlin",
                    AwayTeam = "Bayern München",
                    HomeOdds = 9.0,
                    DrawOdds = 4.5,
                    AwayOdds = 1.45,
                    Time = new DateTime(2020, 05, 18, 18, 30, 0),
                    Category = category_1
                };

                var event_3 = new Event
                {
                    HomeTeam = "Köln",
                    AwayTeam = "Mainz",
                    HomeOdds = 2.3,
                    DrawOdds = 3.0,
                    AwayOdds = 2.8,
                    Time = new DateTime(2020, 05, 18, 18, 30, 0),
                    Category = category_2
                };

                ctx.Add(event_1);
                ctx.Add(event_2);
                ctx.Add(event_3);

                Ticket t1 = new Ticket();
                Ticket t2 = new Ticket();

                t1.Events.Add(event_1);
                t1.Events.Add(event_2);

                t2.Events.Add(event_2);
                t2.Events.Add(event_3);

                ctx.Add(t1);
                ctx.Add(t2);

                ctx.SaveChanges();
            }
        }

        public async Task DeleteEventAsync(int eventId)
        {
            _context.Events.Remove(new Event { Id = eventId });
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if ((await _context.Events
                .SingleOrDefaultAsync(e => e.Id == eventId)) == null)
                    throw new Exception("Nem található a termék");
                else throw;
            }
        }

        public async Task<Event> GetEventAsync(int eventId)
        {
            return (await _context.Events
               .Include(e => e.HomeTeam)
               .Include(e => e.AwayTeam)
               .SingleOrDefaultAsync(e => e.Id == eventId))
               ?? throw new Exception("Nem található a termék");
        }

        public async Task<IEnumerable<Event>> GetEventsAsync()
        {
            var events = await _context.Events
                //.Include(e => e.HomeTeam)
                //.Include(e => e.AwayTeam)
                .ToListAsync();

            return events;
        }

        public async Task<Event> InsertEventAsync(Event newEvent)
        {
            _context.Events.Add(newEvent);
            await _context.SaveChangesAsync();
            return newEvent;
        }

        public async Task UpdateEventAsync(int eventId, Event updatedEvent)
        {
            updatedEvent.Id = eventId;
            var entry = _context.Attach(updatedEvent);
            entry.State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync(); //async változat hívása
            }
            catch (DbUpdateConcurrencyException)
            {
                if ((await _context.Events
                        .SingleOrDefaultAsync(p => p.Id == eventId)) == null)
                    throw new Exception("Nem található a termék");
                else throw;
            }
        }

        public async void SaveToJson(string path)
        {
            var events = await _context.Events
                .ToListAsync();

            string file = path;

            try
            {
                using (StreamWriter sw = File.CreateText(file))
                {
                    JsonSerializer js = new JsonSerializer();
                    js.Serialize(sw, events.ToList());
                }
            }

            catch (Exception e)
            {
                if (e is IOException) { }
                    
            }
        }

        public async void LoadFromJson(string path)
        {
            string json = "";
            try
            {
                using (StreamReader sr = File.OpenText(path))
                {
                    var list = new List<Event>();

                    while (true)
                    {
                        string line = sr.ReadLine();
                        if (line == null) break;
                        json += line;

                    }

                    list = JsonConvert.DeserializeObject<List<Event>>(json);

                    foreach (Event e in list)
                        _context.Events.Add(e);
                    //_context.
                        
                    await _context.SaveChangesAsync();

                }
            }

            catch (Exception e)
            {
                if (e is IOException) { }
            }

        }
    }
}
